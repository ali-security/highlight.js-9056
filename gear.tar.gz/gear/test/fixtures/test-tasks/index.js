exports.fooga = function(dummy, blob, done) {
    done(null, blob);
};
